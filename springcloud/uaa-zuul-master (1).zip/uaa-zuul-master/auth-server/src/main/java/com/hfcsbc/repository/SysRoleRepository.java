package com.hfcsbc.repository;

import com.hfcsbc.domain.SysRole;
import com.hfcsbc.repository.support.WiselyRepository;

/**
 * Created by wangyunfei on 2017/6/9.
 */
public interface SysRoleRepository extends WiselyRepository<SysRole,Long> {
}
