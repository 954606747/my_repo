package com.hfcsbc.repository;

import com.hfcsbc.domain.SysAuthority;
import com.hfcsbc.repository.support.WiselyRepository;

/**
 * Created by wangyunfei on 2017/6/14.
 */
public interface SysAuthotityRepository extends WiselyRepository<SysAuthority,Long>{
}
