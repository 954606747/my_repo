package com.hfcsbc.util;

/**
 * Created by wangyunfei on 2017/6/9.
 */
public final class Constants {
    public static final String ANONYMOUS_USER = "anonymoususer";

}
